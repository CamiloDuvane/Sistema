export async function initializeInternet({ onMessage, onConnectionStatusChange, onUserCountChange }) {
  class InternetConnection {
    constructor() {
      this.ws = null;
      // Using a free WebSocket server that supports user counting
      this.serverUrl = 'wss://demo.piesocket.com/v3/channel_1?api_key=VCXCEuvhGcBDP7XhiJJUDvR1e1D3eiVjgZ9VRiaV';
      this.pingInterval = null;
    }

    async connect() {
      return new Promise((resolve, reject) => {
        try {
          this.ws = new WebSocket(this.serverUrl);
          
          this.ws.onmessage = (event) => {
            try {
              const data = JSON.parse(event.data);
              if (data.type === 'userCount') {
                onUserCountChange(data.count);
              } else if (data.type === 'message') {
                onMessage(data.content);
              }
            } catch (error) {
              // If it's not JSON, treat as regular message
              onMessage(event.data);
            }
          };

          this.ws.onopen = () => {
            onConnectionStatusChange('Conectado via Internet');
            // Start sending periodic pings to keep connection alive
            this.pingInterval = setInterval(() => {
              this.ping();
            }, 30000);
            resolve();
          };

          this.ws.onclose = () => {
            onConnectionStatusChange('Desconectado');
            onUserCountChange(0);
            if (this.pingInterval) {
              clearInterval(this.pingInterval);
            }
          };

          this.ws.onerror = (error) => {
            console.error('WebSocket Error:', error);
            onConnectionStatusChange('Erro na conexão Internet');
            reject(error);
          };
        } catch (error) {
          console.error('Internet Connection Error:', error);
          onConnectionStatusChange('Erro na conexão Internet');
          reject(error);
        }
      });
    }

    ping() {
      this.sendMessage({ type: 'ping' });
    }

    async sendMessage(message) {
      return new Promise((resolve, reject) => {
        if (this.ws && this.ws.readyState === WebSocket.OPEN) {
          try {
            if (typeof message === 'object') {
              this.ws.send(JSON.stringify(message));
            } else {
              const messageObj = {
                type: 'message',
                content: message,
                timestamp: Date.now()
              };
              this.ws.send(JSON.stringify(messageObj));
            }
            resolve();
          } catch (error) {
            reject(new Error('Erro ao enviar mensagem'));
          }
        } else {
          reject(new Error('Conexão WebSocket não está pronta'));
        }
      });
    }
  }

  const connection = new InternetConnection();
  await connection.connect();
  return connection;
}