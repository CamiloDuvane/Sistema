import { initializeWebRTC } from './webrtc.js';
import { initializeBluetooth } from './bluetooth.js';
import { initializeInternet } from './internet.js';
import { ChatUI } from './chat-ui.js';

class ChatApp {
  constructor() {
    this.ui = new ChatUI();
    this.connection = null;
    this.initializeEventListeners();
    this.onlineCount = 0;
  }

  initializeEventListeners() {
    document.getElementById('wifi-connect').addEventListener('click', (e) => {
      e.preventDefault();
      this.connectWiFi();
    });
    
    document.getElementById('bluetooth-connect').addEventListener('click', (e) => {
      e.preventDefault();
      this.connectBluetooth();
    });
    
    document.getElementById('internet-connect').addEventListener('click', (e) => {
      e.preventDefault();
      this.connectInternet();
    });
    
    document.getElementById('send-button').addEventListener('click', (e) => {
      e.preventDefault();
      this.sendMessage();
    });
    
    document.getElementById('message-input').addEventListener('keypress', (e) => {
      if (e.key === 'Enter') {
        e.preventDefault();
        this.sendMessage();
      }
    });
  }

  updateOnlineCount(count) {
    this.onlineCount = count;
    const countElement = document.getElementById('online-count');
    if (countElement) {
      countElement.textContent = count.toString();
    }
  }

  async connectWiFi() {
    try {
      this.ui.updateConnectionStatus('Conectando via Wi-Fi...');
      this.connection = await initializeWebRTC({
        onMessage: (message) => this.handleReceivedMessage(message),
        onConnectionStatusChange: (status) => this.handleStatusChange(status)
      });
    } catch (error) {
      console.error('Erro ao conectar via Wi-Fi:', error);
      this.ui.updateConnectionStatus('Erro na conexão Wi-Fi');
    }
  }

  async connectBluetooth() {
    try {
      this.ui.updateConnectionStatus('Conectando via Bluetooth...');
      this.connection = await initializeBluetooth({
        onMessage: (message) => this.handleReceivedMessage(message),
        onConnectionStatusChange: (status) => this.handleStatusChange(status)
      });
    } catch (error) {
      console.error('Erro ao conectar via Bluetooth:', error);
      this.ui.updateConnectionStatus('Erro na conexão Bluetooth');
    }
  }

  async connectInternet() {
    try {
      this.ui.updateConnectionStatus('Conectando via Internet...');
      this.connection = await initializeInternet({
        onMessage: (message) => this.handleReceivedMessage(message),
        onConnectionStatusChange: (status) => this.handleStatusChange(status),
        onUserCountChange: (count) => this.updateOnlineCount(count)
      });
    } catch (error) {
      console.error('Erro ao conectar via Internet:', error);
      this.ui.updateConnectionStatus('Erro na conexão Internet');
    }
  }

  handleReceivedMessage(message) {
    if (typeof message === 'string') {
      this.ui.addMessage(message, false);
    } else {
      console.warn('Received non-string message:', message);
    }
  }

  handleStatusChange(status) {
    if (typeof status === 'string') {
      this.ui.updateConnectionStatus(status);
    } else {
      console.warn('Received invalid status:', status);
    }
  }

  async sendMessage() {
    const input = document.getElementById('message-input');
    const message = input.value.trim();
    
    if (message && this.connection) {
      try {
        await this.connection.sendMessage(message);
        this.ui.addMessage(message, true);
        input.value = '';
      } catch (error) {
        console.error('Erro ao enviar mensagem:', error);
        this.ui.updateConnectionStatus('Erro ao enviar mensagem');
      }
    }
  }
}

// Initialize the app when DOM is fully loaded
document.addEventListener('DOMContentLoaded', () => {
  window.app = new ChatApp();
});